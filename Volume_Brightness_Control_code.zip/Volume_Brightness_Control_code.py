import cv2 as cv
import numpy as np
import screen_brightness_control as scb
from cvzone.HandTrackingModule import HandDetector
import pyautogui
import time

# Function to set system volume
def set_volume(volume):
    # Adjust as needed for your system
    if volume > 0.5:
        pyautogui.press('volumeup')
    else:
        pyautogui.press('volumedown')

# Set webcam resolution to 1000x1000
cap = cv.VideoCapture(0)
cap.set(3, 1000)  # Width
cap.set(4, 1000)  # Height

hd = HandDetector()
left_brightness_val = 0
right_volume_val = 0

# Display welcome text for 7 seconds
start_time = time.time()
display_time = 7

while time.time() - start_time < display_time:
    _, img = cap.read()
    cv.putText(img, "Volume - Brightness Control Using Hand Gesture", (50, 50),
               cv.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    cv.imshow('frame', img)
    cv.waitKey(1)

while True:
    _, img = cap.read()
    hands, img = hd.findHands(img)

    if hands:
        left_hand = hands[0]['lmList'][0] < hands[0]['lmList'][5]  # Assuming left hand has index finger lower
        lm = hands[0]['lmList']

        # Adjust brightness with the left hand
        if not left_hand:
            length, _, img = hd.findDistance(lm[8][0:2], lm[4][0:2], img)
            # Reverse the interpolation to increase brightness when moving upwards
            left_brightness_val = np.interp(length, [25, 145], [0, 100])
            left_brightness_val = int(left_brightness_val)
            scb.set_brightness(left_brightness_val)

            # Draw brightness bar for left hand
            cv.rectangle(img, (20, 150), (85, 400), (0, 255, 255), 4)
            filled_rect_height = int(left_brightness_val * 2.5)
            cv.rectangle(img, (20, 400 - filled_rect_height), (85, 400), (0, 0, 255), -1)  # Decrease in height
            cv.putText(img, str(left_brightness_val) + '%', (20, 430), cv.FONT_HERSHEY_COMPLEX, 1, (255, 0, 0), 3)

        # Adjust volume with the right hand
        else:
            length, _, img = hd.findDistance(lm[4][0:2], lm[8][0:2], img)  # Distance between thumb and index finger
            right_volume_val = np.interp(length, [50, 200], [0, 1])  # Volume should be between 0 and 1
            set_volume(right_volume_val)

            # Draw volume bar for right hand
            cv.rectangle(img, (100, 150), (165, 400), (255, 0, 0), 4)
            filled_rect_height = int(right_volume_val * 250)
            cv.rectangle(img, (100, 400 - filled_rect_height), (165, 400), (0, 255, 0), -1)  # Decrease in height
            cv.putText(img, str(int(right_volume_val * 100)), (100, 430), cv.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 3)

    cv.imshow('frame', img)
    if cv.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv.destroyAllWindows()
